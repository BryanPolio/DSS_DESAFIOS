package com.example.propinas

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etMonto: EditText
    private lateinit var etPersonas: EditText
    private lateinit var rgPropina: RadioGroup
    private lateinit var etPropinaPersonalizada: EditText
    private lateinit var switchIva: Switch
    private lateinit var btnCalcular: Button
    private lateinit var btnLimpiar: Button
    private lateinit var tvResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etMonto = findViewById(R.id.etMonto)
        etPersonas = findViewById(R.id.etPersonas)
        rgPropina = findViewById(R.id.rgPropina)
        etPropinaPersonalizada = findViewById(R.id.etPropinaPersonalizada)
        switchIva = findViewById(R.id.switchIva)
        btnCalcular = findViewById(R.id.btnCalcular)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        tvResultado = findViewById(R.id.tvResultado)

        rgPropina.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbOtro) {
                // Mostrar campo para propina manual
                etPropinaPersonalizada.visibility = View.VISIBLE
            } else {
                etPropinaPersonalizada.visibility = View.GONE
                etPropinaPersonalizada.text.clear()
            }
        }

        btnCalcular.setOnClickListener { calcular() }
        btnLimpiar.setOnClickListener { limpiar() }
    }

    private fun calcular() {
        val montoStr = etMonto.text.toString()
        val personasStr = etPersonas.text.toString()

        // Validaciones de vacíos
        if (montoStr.isEmpty()) {
            etMonto.error = getString(R.string.error_vacio)
            return
        }
        if (personasStr.isEmpty()) {
            etPersonas.error = getString(R.string.error_vacio)
            return
        }

        val monto = montoStr.toDoubleOrNull() ?: 0.0
        val personas = personasStr.toIntOrNull() ?: 0

        // Validaciones matemáticas
        if (monto <= 0) {
            etMonto.error = getString(R.string.error_invalido)
            return
        }
        if (personas <= 0) {
            etPersonas.error = getString(R.string.error_invalido)
            return
        }

        // Obtener el porcentaje
        var porcentaje = 0.0
        when (rgPropina.checkedRadioButtonId) {
            R.id.rb10 -> porcentaje = 10.0
            R.id.rb15 -> porcentaje = 15.0
            R.id.rb20 -> porcentaje = 20.0
            R.id.rbOtro -> {
                val customPropina = etPropinaPersonalizada.text.toString().toDoubleOrNull()
                if (customPropina == null || customPropina < 0) {
                    etPropinaPersonalizada.error = getString(R.string.error_invalido)
                    return
                }
                porcentaje = customPropina
            }
        }

        // Matemáticas finales
        val iva = if (switchIva.isChecked) monto * 0.16 else 0.0
        val propina = monto * (porcentaje / 100)
        val total = monto + iva + propina
        val porPersona = total / personas

        // Mostramos formateado
        tvResultado.text = getString(R.string.resultado_txt, propina, total, porPersona)
    }

    private fun limpiar() {
        etMonto.text.clear()
        etPersonas.text.clear()
        rgPropina.check(R.id.rb10) // Regresa al 10% por defecto
        switchIva.isChecked = false
        tvResultado.text = ""
        etMonto.requestFocus()
    }
}